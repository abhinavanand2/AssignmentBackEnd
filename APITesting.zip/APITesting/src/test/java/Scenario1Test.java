import java.io.File;

import org.testng.annotations.Test;

public class Scenario1Test {

	public static String url = Restutil
			.propReader(System.getProperty("user.dir") + File.separator + "config.properties", "BaseURL");
	public static String empDp = Restutil
			.propReader(System.getProperty("user.dir") + File.separator + "config.properties", "endpoint");

	@Test(priority = 1)
	public static void testStatusScenario2() {
		System.out.println(url + "employees");
		ApiMethods.get(url + empDp).then().assertThat().statusCode(200);
	}

	@Test(priority = 2)
	public static void verifyProfileImage() {
		ApiMethods.get(url + empDp).then().extract().path("data.profile_image").equals("");
	}
}
