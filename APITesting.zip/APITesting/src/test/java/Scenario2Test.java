import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import java.io.File;

import org.testng.annotations.Test;

public class Scenario2Test {
	@Test(priority = 3)
	public static void testStatusSCenario2() {
		for (int i = 0; i < Restutil.uriGenerator().length; i++) {
			System.out.println(Restutil.uriGenerator()[i]);
			ApiMethods.get(Restutil.uriGenerator()[i]).then().assertThat().statusCode(200);
			System.out.println("Stats code checked");
		}

	}

	@Test(priority = 4)
	public static void testBodyPattern() {
		for (int i = 0; i < Restutil.uriGenerator().length; i++) {
			System.out.println(Restutil.uriGenerator()[i]);
			ApiMethods.get(Restutil.uriGenerator()[0]).then().assertThat().body(matchesJsonSchemaInClasspath(
					System.getProperty("user.dir") + File.separator + "src/main/resources/valid.json"));
			System.out.println("Body Pattern Checked");
		}
	}

	@Test(priority = 5)
	public static void testMessage() {
		for (int i = 0; i < Restutil.uriGenerator().length; i++) {
			System.out.println(Restutil.uriGenerator()[i]);
			ApiMethods.get(Restutil.uriGenerator()[i]).then().extract().path("message")
					.equals("Successfully! Record has been fetched.");
			System.out.println("Successfull message checked");
		}
	}

}
