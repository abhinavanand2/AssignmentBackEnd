import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Restutil {
	public static String propReader(String fileName, String key) {
		Properties prop = new Properties();
		try {
			FileInputStream fis = new FileInputStream(fileName);
			prop.load(fis);
		} catch (IOException ioe) {
			System.out.println(ioe);
		}
		return prop.getProperty(key);
	}

	public static String[] uriGenerator() {

		String[] URIList = {};

		String url = Restutil.propReader(System.getProperty("user.dir") + File.separator + "config.properties",
				"BaseURL");
		String endPoint = Restutil.propReader(System.getProperty("user.dir") + File.separator + "config.properties",
				"endpoint1");
		try {
			File testData = new File(System.getProperty("user.dir") + File.separator + "TestData.xlsx");
			FileInputStream fis = new FileInputStream(testData);
			@SuppressWarnings("resource")
			XSSFWorkbook myExcelBook = new XSSFWorkbook(fis);
			XSSFSheet myExcelSheet = myExcelBook.getSheet("IDS");

			if (endPoint.contains("{")) {
				URIList = new String[myExcelSheet.getLastRowNum()];
				for (int i = 1; i <= myExcelSheet.getLastRowNum(); i++) {
					String id = Integer.toString((int) myExcelSheet.getRow(i).getCell(0).getNumericCellValue());
					URIList[i - 1] = url + endPoint.replace("{id}", id);
				}

			}

		} catch (IOException ex) {
			System.out.println(ex);
		}

		return URIList;

	}

	public static void main(String[] args) {

		System.out.println(System.getProperty("user.dir") + File.separator + "src/main/resources/valid.json");

	}
}
