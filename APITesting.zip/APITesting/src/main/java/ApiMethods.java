import io.restassured.RestAssured;
import io.restassured.response.Response;

public class ApiMethods {
	public static Response get(String endpoint) {
		return RestAssured.given().when().get(endpoint);
	}
}
