package ListConcepts;

import java.util.ArrayList;

public class ArrayListConcept {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]=new int[4];//static array
		a[0]=0;
		a[1]=10;
		a[2]=20;
		a[3]=50;
		
		System.out.println(a.length);
		System.out.println(a[0]);
		System.out.println(a[1]);
		System.out.println(a[2]);
		System.out.println(a[3]);
		
		
		ArrayList<Integer> a1 =new ArrayList<Integer>(); //dynamic array
		a1.add(23);
		a1.add(34);
		a1.add(56);
		a1.add(27);
		a1.add(89);
		System.out.println(a1.size());
		a1.add(54);
		System.out.println(a1.size());
		System.out.println(a1);
		
		
		
		
		
		
		
		
		

	}

}
