package oopsInheritance;

public class BMW extends Car { //has a relationship

	
	// when same method is present in parent class as well as child class with the same name and same no of argument is known as METHOD OVERRIDING.
	public void start() {  
		
		System.out.println("BMW--starts");
	}
	
	public void auto() {
		
		System.out.println("BMW--Auto");
	}
	
public void insurance() {
		
		System.out.println("BMW--insurance");
	}
	
}
