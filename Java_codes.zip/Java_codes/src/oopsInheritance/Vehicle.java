package oopsInheritance;

public class Vehicle {

	public void engine() {
	
		System.out.println("Vehicle--engine");
	}
}
