package oopsInheritance;

public class TestInheritance {

	public static void main(String[] args) {
		
		//Static ploymorphism-- Compile time polymorphism
		BMW b = new BMW();
		b.start();
		b.stop();
		b.refuel();
		b.auto();
		b.insurance();
		b.engine();
		
		System.out.println("***************");
		
		Car c = new BMW(); //child class object can be referred by parent class reference variable--dynamic polymorphism >> Run time polymorphism
		c.start();
		c.stop();
		c.refuel();
		c.engine();
		
		System.out.println("***************");
		
		Car c1 = new Car();
		c1.engine();
		c1.start();
		c1.stop();
		c1.refuel();
		
		System.out.println("***************");
		
		BMW bc = (BMW) new Car(); //will throw java.lang.ClassCasrException
		bc.auto();
		bc.insurance();
		bc.start();
		bc.stop();
		bc.refuel();
		
		

	}

}
