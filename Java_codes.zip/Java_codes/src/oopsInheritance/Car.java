package oopsInheritance;

public class Car extends Vehicle {

	public void start() {
		System.out.println("Car--starts");
	}
	
	public void stop() {
		System.out.println("Car--stop");
	}
	
	public void refuel() {
		System.out.println("Car--refuel");
	}

}
