package oopsInterface;

public interface USBank {
	
	int min_amount=2000;
	public void transactions();
	public void mutualFunds();
	public void loans();
	
	
	//Only method declaration
	//No method body-only method prototype
	//in interface,we can declare the variables 
	//variables are by default static in nature
	//vars value will not be changed
	//no static method method in interface
	//no main method in interface
	//we can create the object of the interface
	//interface is abstract in nature
	
	
	
	

}
