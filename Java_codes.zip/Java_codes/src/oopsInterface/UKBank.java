package oopsInterface;

public interface UKBank {

	int min_loanAmount=50000;
	public void debit();
	public void credit();
	public void account();
	
}
