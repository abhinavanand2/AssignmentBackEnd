package oopsInterface;

public class TestInterface {

	public static void main(String[] args) {

		HDFC hdfc=new HDFC();
		hdfc.transactions();
		hdfc.loans();
		hdfc.mutualFunds();
		System.out.println(USBank.min_amount);
		System.out.println(UKBank.min_loanAmount);
		System.out.println("**************");
		
		hdfc.credit();
		hdfc.debit();
		hdfc.account();
		System.out.println("**************");
		
		//dynamic polymorphism-- 
		//child class object can be referred by parent interface reference variable.
		USBank ub =new HDFC();
		ub.transactions();
		ub.loans();
		ub.mutualFunds();
		System.out.println("**************");
		
		UKBank uk =new HDFC();
		uk.credit();
		uk.debit();
		uk.account();
		System.out.println("**************");
		
		ICICI ic = new ICICI();
		ic.credit();
		ic.debit();
		ic.account();
		ic.loans();
		ic.mutualFunds();
		ic.transactions();
		
		
		
		
		
		
		
		
		
	}

}
