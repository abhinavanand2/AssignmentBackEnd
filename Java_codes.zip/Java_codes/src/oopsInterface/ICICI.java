package oopsInterface;

public class ICICI implements USBank,UKBank {

	@Override
	public void debit() {
		
		System.out.println("UKBank--debit");
		
	}

	@Override
	public void credit() {
		System.out.println("UKBank--credit");
		
	}

	@Override
	public void account() {
		System.out.println("UKBank--account");
		
	}

	@Override
	public void transactions() {
		System.out.println("USBank--transaction");
		
	}

	@Override
	public void mutualFunds() {
		System.out.println("USBank--mutuakFunds");
		
	}

	@Override
	public void loans() {
		System.out.println("USBank--loans");
		
	}

}
