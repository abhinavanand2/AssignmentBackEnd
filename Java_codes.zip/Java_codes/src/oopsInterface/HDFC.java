package oopsInterface;

public class HDFC implements USBank,UKBank { //achieving multiple inheritance
	//is a relationship

	@Override
	public void transactions() {
		
		System.out.println("USBank--transaction");
	}

	@Override
	public void mutualFunds() {

		System.out.println("USBank--mutualFunds");
		
	}

	@Override
	public void loans() {
		
		System.out.println("USBank--loans");
		
	}
	
	public void debit() {
		
		System.out.println("UKBank--debit");
	}
	
	public void credit() {

		System.out.println("UK--Credit");
		
	}
	
	public void account() {
		
		System.out.println("UK--Account");
	}
	
	
	

}
