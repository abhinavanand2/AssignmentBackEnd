package OopsConcept;

public class MethodOverloading {

	public static void main(String[] args) {
		
		MethodOverloading obj =new MethodOverloading();
		obj.sum();
		obj.sum(10);
		obj.sum(20, 30);
		obj.sum(10.00);

	}
	
	public void sum() {
		
		System.out.println("sum-param");
		
	}
	
	public void sum(int a) {
		
		System.out.println("single-param");
		
		}
	
	public void sum(int p, int q) {
		
		System.out.println("double- param");
		
	}
	
	public void sum(double d) {
		
		System.out.println("different data type");
	}

}
