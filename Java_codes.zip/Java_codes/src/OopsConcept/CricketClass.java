package OopsConcept;

public class CricketClass {
	
	int odi;
	int test;
	
	public static void main(String[] args) {
		
		CricketClass matches = new CricketClass();
		CricketClass runScored = new CricketClass();
		CricketClass wickets = new CricketClass();
		
		matches.odi=200;
		matches.test=85;
		
		runScored.odi=3000;
		runScored.test=5000;
		
		wickets.odi=300;
		wickets.test=500;
		
		System.out.println(matches.odi);
		System.out.println(matches.test);
		
		System.out.println(runScored.odi);
		System.out.println(runScored.test);
		
		System.out.println(wickets.odi);
		System.out.println(wickets.test);
		
		
		

	}

}
