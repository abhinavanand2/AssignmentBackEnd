package OopsConcept;

public class Methods {

	public static void main(String[] args) {
		
		Methods crick = new Methods();
		int l=crick.runs(2000, 4000);
		System.out.println(l);
		
		crick.test();
		crick.players();
		

	}
	
	public void test() {
		System.out.println("executed test");
	
	}
	
	public String players() {
		
		System.out.println("Sachin&Ganguly");
		String s="Dravide";
		return s;
		
	}
	
	public int runs(int x,int y) {
		int i = y/x;
		return i;
	}

}
