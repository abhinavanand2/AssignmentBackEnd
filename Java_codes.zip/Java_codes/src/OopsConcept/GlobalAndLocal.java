package OopsConcept;

public class GlobalAndLocal {
	
	
	String name="tom"; // global variable and non static
	int age=24;
	static double d =10.00;
	
	

	public static void main(String[] args) {
		
		int i =10; // local variable
		System.out.println(i);
		GlobalAndLocal var = new GlobalAndLocal();
		System.out.println(var.age);
		System.out.println(var.name);
		System.out.println(d);
		System.out.println(GlobalAndLocal.d);
		var.sum();
		add();
		GlobalAndLocal.add();
		

	}
	
	public void sum() {
		
		int j=23; //local variable
		int k =45;
		System.out.println(j);
		System.out.println(k);
		
	}
	
	public static void add() {
		
		System.out.println("static");
	}

}
