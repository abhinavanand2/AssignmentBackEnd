package OopsConcept;

public class WrapperClass {

	public static void main(String[] args) {
		
		String x = "100"; // Data conversion:String to int
		System.out.println(x);
		int i = Integer.parseInt(x);
		System.out.println(i+10);
		
		String z = "True";
		System.out.println(z);
		boolean b = Boolean.parseBoolean(z);
		System.out.println(b);
		
		String s ="22.22";
		System.out.println(s);
		double d = Double.parseDouble(s);
		System.out.println(d);
		
		
		//int to string conversion
		int j =55;
		String s1=String.valueOf(j);
		System.out.println(s1);
		
		
		
		

	}

}
