package basicPractice;

public class StringConcat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a = 50;
		int b =30;
		String c = "hello";
		String d = "world";
		
		System.out.println(a+b);
		System.out.println(c+d);
		System.out.println(a+b+c+d);//80helloworld
		System.out.println(c+d+a+b);//helloworld5030
		System.out.println(c+d+(a+b));//helloworld80
		System.out.println(a+b+c+d+a+c+b+d);//80helloworld50hello30world
		
		System.out.println("The value of 100 is "+c +d);
		
		System.out.print("Hi This is Amazing");
		System.out.println(" This is without new line");
	}

}
