package basicPractice;

public class MultiDimensionalArray {

	public static void main(String[] args) {
		
		int j[][]=new int[2][3];
		j[0][0]=21;
		j[0][1]=23;
		j[0][2]=25;
		j[1][0]=11;
		j[1][1]=17;
		j[1][2]=65;
		
		System.out.println(j.length);
		System.out.println(j[0].length);
		
		for(int row=0;row<j.length;row++) {
			for(int col=0;col<j[0].length;col++) {
				
				System.out.println(j[row][col]);
			}
		}
		
		

	}

}
