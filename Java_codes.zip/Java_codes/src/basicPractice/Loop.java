package basicPractice;

public class Loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		for(int i=10;i>=-9;i--) {
			
			System.out.println(i);
		}

		
		int j =1;
		while(j<=10) {
			
			System.out.println(j);
			j=j+1;
		}
	
	
	for(int k=0;k<=10;k++)
	{
		System.out.println(k);
	}

}
}


