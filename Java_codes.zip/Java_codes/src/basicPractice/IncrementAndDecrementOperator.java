package basicPractice;

public class IncrementAndDecrementOperator {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i =1;
		int j = i++;
		System.out.println(i);
		System.out.println(j);
		
		int k =1;
		int l = ++k;
		System.out.println(k);
		System.out.println(l);
		
		int m =2;
		int n = m--;
		System.out.println(m);
		System.out.println(n);
		
		int o =2;
		int p = --o;
		System.out.println(o);
		System.out.println(p);
		

		

	}

}
