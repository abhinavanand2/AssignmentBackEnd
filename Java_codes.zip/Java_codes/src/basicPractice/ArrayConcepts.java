package basicPractice;

public class ArrayConcepts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int i[]=new int[3];
		boolean b[] = new boolean[2];
		double d[]=new double[2];
		char c[]=new char[2];
		String s[]=new String[2];
		
		
		i[0]=1;
		i[1]=4;
		i[2]=5;
		
		b[0]=true;
		b[1]=false;
		
		d[0]= 100;
		d[1]=1000.00;
		
		c[0]='b';
		c[1]='c';
		
		s[0]="abhi";
		s[1]="anand";
		
		System.out.println(i.length);
		System.out.println(b.length);
		System.out.println(d.length);
		System.out.println(c.length);
		System.out.println(s.length);
		
		
		System.out.println(i[2]);
		System.out.println(b[1]);
		System.out.println(d[1]);
		System.out.println(c[0]);
		System.out.println(s[0]);
		
		
		Object o[]=new Object[4];
		o[0]=100;
		o[1]="abhi";
		o[2]='d';
		o[3]=true;
		
		System.out.println(o[0]);
		System.out.println(o[1]);
		System.out.println(o[2]);
		System.out.println(o[3]);
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
