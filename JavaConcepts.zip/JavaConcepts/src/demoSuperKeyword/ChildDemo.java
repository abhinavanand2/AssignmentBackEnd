package demoSuperKeyword;

public class ChildDemo extends ParentDemo {
	
	String name = "Abhi";
	
	public ChildDemo() {
		
		super(); // calling parent class constructor and this should be the always the first line inside constructor
		System.out.println("Child class constructor");
	}
	
	public void getName() {
		
		System.out.println(name);
		System.out.println(super.name);//will call parent class variable
		System.out.println("I am in child class");
		super.getName(); //will call parent class method
	}

	public static void main(String[] args) {
		
		ChildDemo cd = new ChildDemo();
		cd.getName();
		

	}

}
