package demoSuperKeyword;

public class ParentDemo {

	String name = "Rahul";

	public ParentDemo() {

		System.out.println("Parent class constructor");
	}

	public void getName() {

		System.out.println("I am in parent class");
	}

	public static void main(String[] args) {

	}

}
