package basicAbstraction;

public abstract class ParentAirCraft {
	
	public void engine() {
		
		System.out.println("engine Implemented");
	}
	
	public void safetyGuidelines() {
		
		System.out.println("SafetyGuidelines Implemented");
	}
	
	public abstract void color();

}
