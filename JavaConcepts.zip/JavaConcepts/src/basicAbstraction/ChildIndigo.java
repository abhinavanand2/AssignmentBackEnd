package basicAbstraction;

public class ChildIndigo extends ParentAirCraft {

	public static void main(String[] args) {

		ChildIndigo ch = new ChildIndigo();
		ch.engine();
		ch.color();
		ch.safetyGuidelines();

	}

	@Override
	public void color() {
	
		System.out.println("Color is Red");
		
	}

}
