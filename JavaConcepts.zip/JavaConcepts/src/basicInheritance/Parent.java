package basicInheritance;

public class Parent {
	
	String status ="Stable";
	
	public void run() {
		
		System.out.println("Running");
	}
	
	public void stop() {
		
		System.out.println("Stopping");
	}
	
	public void walk() {
		
		System.out.println("walking");
		
	}

}
