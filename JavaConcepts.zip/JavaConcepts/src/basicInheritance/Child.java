package basicInheritance;

public class Child extends Parent {
	
	public void currentsStatus() {
		
		System.out.println(status);
	}

	public static void main(String[] args) {
		
		Child ch = new Child();
		ch.run();
		ch.stop();
		ch.walk();
		ch.currentsStatus();
		
		

	}

}
