package practiceClassAndMethods;

public class BasicString {

	public static void main(String[] args) {
		
		//String str=new String("hello");//string class
		
		String s = "Java String training"; //string literal
		System.out.println(s.charAt(5));
		System.out.println(s.indexOf("a"));
		System.out.println(s.substring(0,11));
		System.out.println(s.substring(0));
		System.out.println(s.concat(" to understand string"));
		System.out.println(s.length());
		System.out.println(s.trim());
		System.out.println(s.toUpperCase());
		System.out.println(s.toLowerCase());
		String arr[]=s.split("S");
		System.out.println(arr[0]);
		System.out.println(arr[1]);
		System.out.println(s.replace("t", "s"));
		
		
		
	}

}
