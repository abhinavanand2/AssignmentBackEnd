package practiceClassAndMethods;

public class Methods {

	public  void BasicCalc()
	{
		// TODO Auto-generated method stub
		
		int a = 10;
		int b = 9;
		int c , d , m, s;
		
		c = a+b;
		d = a/b;
		m = a*b;
		s = a-b;
		
		System.out.println(c);
		System.out.println(d);
		System.out.println(m);
		System.out.println(s);
		

	}

}
