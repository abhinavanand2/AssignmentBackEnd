package practiceClassAndMethods;

public class Parent {

	public static void main(String[] args) {
	
		System.out.println("learn method cal");
		Methods m = new Methods();
		m.BasicCalc();
		
		
		
		
			

	}

}
