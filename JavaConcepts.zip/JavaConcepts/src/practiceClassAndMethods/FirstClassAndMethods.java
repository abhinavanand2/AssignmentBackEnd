package practiceClassAndMethods;

public class FirstClassAndMethods {

	static int a = 200;
	
	public void getData()
	{
		System.out.println("Lets create a method");
	}
	
	public static void main(String[] args) {
		
		FirstClassAndMethods create = new FirstClassAndMethods();
		create.getData();
		System.out.println(create.a);
		Methods m = new Methods();
		m.BasicCalc();
		
		

	}

}
