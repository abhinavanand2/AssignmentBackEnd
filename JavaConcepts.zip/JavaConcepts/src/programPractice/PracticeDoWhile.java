package programPractice;

public class PracticeDoWhile {

	public static void main(String[] args) {


		int j =20;
		do {
			
			System.out.println(j);
			j++;
		}
		while(j<30);// 1 loop of execution is guaranteed
		{
			
		}
	}

}
