package programPractice;

public class PracticeWhileLoop {

	public static void main(String[] args) {
		
		//print value from 1o to 1
		
		int i = 10;
		while(i>0) {
			
			System.out.println(i);
			i--;
			
		}

	}

}
