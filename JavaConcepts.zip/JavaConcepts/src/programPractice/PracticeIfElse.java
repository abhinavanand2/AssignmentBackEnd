package programPractice;

public class PracticeIfElse {

	public static void main(String[] args) {

		int a = 493;
		int b = 578;
		int c = 250;

		c = a + b;
		b = a + c;
		a = b + c;

		if (a == b) {

			System.out.println("condition true");
		}

		if (b > c) {

			System.out.println("Nested condition true");
		} else {

			System.out.println(" condition false");
		}
		
		for(int i=0;i<10;i++) {
			if(i==9) {
				System.out.println("display 9");
			}
			
			else {
				System.out.println("didnt get 9");
			}
		}

	}

}
