package programPractice;

public class PracticeForLoop {

	public static void main(String[] args) {

		// print number from 1 to 10

		for (int i = 0; i <= 10; i++) {

			System.out.println(i);
		}

		// print reverse 10 to 1

		for (int j = 10; j >= 0; j--) {

			System.out.println(j);
		}

	}

}
