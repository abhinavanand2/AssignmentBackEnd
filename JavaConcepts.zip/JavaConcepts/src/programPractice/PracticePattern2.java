package programPractice;

public class PracticePattern2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String k = "*";
		for(int i=0;i<+4;i++) {
			
			for(int j=1;j<=4-i;j++) {
				
				System.out.print(k);
				System.out.print("\t");
				
			}
			
			System.out.println("");
		}

	}

}
