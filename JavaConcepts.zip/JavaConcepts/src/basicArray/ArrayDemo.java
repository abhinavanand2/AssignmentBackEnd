package basicArray;

public class ArrayDemo {

	public static void main(String[] args) {
		
		int a[]= new int [6];
		a[0]=2;
		a[1]=4;
		a[2]=12;
		a[3]=22;
		a[4]=2;
		a[5]=24;
		
		for(int i=0;i<a.length;i++) {
			
			System.out.println(a[i]);
		}
		
		
		int b[] = {2,5,3,8,9};
		for(int j=0;j<b.length;j++) {
			
			System.out.println(b[j]);
			
		}
		
		

	}

}
