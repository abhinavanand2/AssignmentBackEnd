package basicArray;

public class MultidimensionalArray {

	public static void main(String[] args) {
		
		int a[][]= new int[2][3];
		a[0][0]= 2;
		a[0][1]= 3;
		a[0][2]= 5;
		a[1][0]= 8;
		a[1][1]= 9;
		a[1][2]= 1;
		
		System.out.println(a[0][2]);
		System.out.println(a[1][2]);
		System.out.println(a[0][0]);
		
		
		int b[][]= {{3,4,5},{5,8,9}};
		System.out.println(b[1][2]);
		System.out.println(b[1][1]);
		
		
		
	}

}
