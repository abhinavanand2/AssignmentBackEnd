package basicArray;

public class PracticeMultiDimensional {

	public static void main(String[] args) {
		
		int a[][]= new int[2][3];
		a[0][0]= 2;
		a[0][1]= 3;
		a[0][2]= 5;
		a[1][0]= 8;
		a[1][1]= 9;
		a[1][2]= 1;
		
		System.out.println(a.length);
		
		for(int i=0;i<2;i++)  //row
		{
			for (int j =0;j<3;j++) { //column
				
				System.out.println(a[i][j]);
			}
			
		}
		
		
		

	}

}
