package basicPolymorphism;

public class BasicOverloading {
	
	public void getData(int a ) {
		
		System.out.println(a);
		
	}
	
	public void getData(String a) {
		
		System.out.println(a);
	}
	
	public void getData(int a , int b) {
		
		System.out.println(a+b);
	}

	public static void main(String[] args) {
	
		BasicOverloading ba = new BasicOverloading();
		ba.getData(100);
		ba.getData("HELLO");
		ba.getData(35, 45);
		

	}

}
