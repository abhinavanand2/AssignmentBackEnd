package basicPolymorphism;

public class Parent {
	
	public void go () {
		
		System.out.println("go implemented");
	}

	public void get() {
		
		System.out.println("get implemented");
	}

	public void set() {

		System.out.println("parent set implemented");
	}


}
