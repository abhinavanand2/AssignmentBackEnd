package basicPolymorphism;

public class BasicOverriding extends Parent{
	
	
	  public void set() {
	  
	  System.out.println("set child implemented"); }
	 
	 

	public static void main(String[] args) {
		
		BasicOverriding br = new BasicOverriding();
		br.get();
		br.go();
		br.set();
		


	}

}
