package basicJava;

public class MethodOver {

	public static void main(String[] args) {
		
		MethodOver m =  new MethodOver();
		m.sum(10, 20);
		m.sum(10, 30, 40);

	}
	
	public int sum(int a , int b) {
		
		System.out.println("Method with two parameters");
		int c = a +b;
		System.out.println(c);
		return c;
	}
	
	public int sum(int x ,int y, int z) {
		
		System.out.println("Method with three parameters");
		int w = x+y+z;
		System.out.println(w);
		return w;
		
	}
}
