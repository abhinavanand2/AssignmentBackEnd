package basicConstructor;

public class DemoConstructor {
	
	public DemoConstructor() {
		
		System.out.println("I am constructor");
	}

	public DemoConstructor(int a, int b) {
		
		System.out.println("I am not a real constructor");
	}
	
public DemoConstructor(String str) {
		
		System.out.println("I am string constructor");
	}
	

	public static void main(String[] args) {
		
		DemoConstructor dc = new DemoConstructor("hello");
		DemoConstructor dc1 = new DemoConstructor(20,30);

	}

}
