package demoThisKeyword;

public class DemoThis {
	
	int a = 20;
	
	 public void getData() {
		 
		 System.out.println(this.a);
		 int a=30;
		 int b = a+this.a;
		 System.out.println(b);
		 System.out.println(a); //this refer to current object 
	 }

	public static void main(String[] args) {
		
		DemoThis dt = new DemoThis();
		dt.getData();

	}

}
