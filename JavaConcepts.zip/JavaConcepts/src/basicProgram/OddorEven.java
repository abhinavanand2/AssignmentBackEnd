package basicProgram;

public class OddorEven {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int number =20;
		if(number%2==0)
		{
			System.out.println(number +  " is even number");
		}
		else {
			
			
			System.out.println(number +  " is  odd number");
			
		}

	}

}
