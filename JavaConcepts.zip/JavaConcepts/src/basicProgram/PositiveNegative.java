package basicProgram;

public class PositiveNegative {

	public static void main(String[] args) {
		 int num  =0;
		 
		 if (num>0) {
			 
			 System.out.println(num + " is positive");
		 }

		 if(num<0) {
			 
			 System.out.println(num + " is negative");
		 }
		 
		 if(num==0)
			 
			 System.out.println(num + " is zero");
		 }
	}


