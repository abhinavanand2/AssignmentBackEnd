package basicProgram;

public class SumNaturalNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num=100,sum=0;
		
		for(int i =1;i<=num;++i)
		{
			sum = sum+i;
			System.out.println(" sum = " + sum );
		}
	}

}
