package basicProgram;

public class Palindrome {

	public static void main(String[] args) {
		
		

	}

}
