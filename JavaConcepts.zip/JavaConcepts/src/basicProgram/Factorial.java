package basicProgram;

public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int count=10;
		long factorial = 1;
		
		for(int i= 1;i<=count;++i)
		{
			
			factorial = factorial*i;
			System.out.printf("Factorial of %d = %d", count, factorial);
		}
	}

}
