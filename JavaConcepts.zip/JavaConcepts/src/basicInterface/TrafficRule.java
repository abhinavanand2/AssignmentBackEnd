package basicInterface;

public class TrafficRule implements PracticeOne,PracticeTwo {

	public static void main(String[] args) {

		PracticeOne traffic = new TrafficRule();
		traffic.greenGo();
		traffic.redStop();
		traffic.flashYellow();
		
		TrafficRule traffic1 = new TrafficRule();
		traffic1.walkSafe();
		
		PracticeTwo traffic2 = new TrafficRule();
		traffic2.trainStop();
		traffic2.metroStop();
		
	}
	
	public void walkSafe() {
		
		System.out.println("Please walk safe");
	}

	@Override
	public void greenGo() {
		
		System.out.println("Green implemented");
		
	}

	@Override
	public void redStop() {
		System.out.println("Red implemented");
		
		
	}

	@Override
	public void flashYellow() {
		System.out.println("Yellow implemented");
		
	}

	@Override
	public void trainStop() {
	
		System.out.println("Stop Train implemented");
		
	}

	@Override
	public void metroStop() {

		System.out.println("Stop metro implemented");
		
	}
	
	
	

}
