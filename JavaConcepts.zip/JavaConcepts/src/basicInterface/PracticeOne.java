package basicInterface;

public interface PracticeOne {

	public void greenGo();
	public void redStop();
	public void flashYellow();
	
}
