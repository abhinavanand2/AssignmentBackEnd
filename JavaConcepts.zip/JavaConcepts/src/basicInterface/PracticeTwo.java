package basicInterface;

public interface PracticeTwo {
	
	public void trainStop();
	public void metroStop();

}
